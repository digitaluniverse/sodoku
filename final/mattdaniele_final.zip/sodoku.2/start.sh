#!/bin/sh
/etc/init.d/apache2 start