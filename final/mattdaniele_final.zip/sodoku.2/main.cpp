#include "sudoku.h"
int main(){
    sudoku s1;
    return 0;
}